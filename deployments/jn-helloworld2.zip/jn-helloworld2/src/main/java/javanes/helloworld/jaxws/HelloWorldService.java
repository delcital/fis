package javanes.helloworld.jaxws;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import javanes.helloworld.InputParameters;
import javanes.helloworld.OutputParameters;

public class HelloWorldService implements Processor{
	
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		//InputSOATest in = new InputSOATest();
		OutputParameters out = new OutputParameters();
        
        //Datos de entrada
        
        String jn_nombre;
        String jn_area;
        long sequence;
        
        //Datos de salida
        
        //Get input from exchange
        jn_nombre = exchange.getIn().getBody(InputParameters.class).getJnNombre();
        jn_area = exchange.getIn().getBody(InputParameters.class).getJnArea();
        
        // REQUESTDATE LOG INI
     		DateFormat formatterLog = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
     		Date fechaIni = new Date();
     		String strRequestDate = formatterLog.format(fechaIni);
     	
        out.setJnCodigo("0");
        out.setJnMensaje("Hi: "+jn_nombre+" from: "+jn_area+" May the Fuse be with u! ");
        
        //set output in exchange
        
        exchange.getOut().setBody(out);

	}

}
